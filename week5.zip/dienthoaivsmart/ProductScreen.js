import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Rating } from 'react-native-elements';
import { useNavigation } from '@react-navigation/native';

const ProductScreen = () => {
  const navigation = useNavigation();

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Hình ảnh sản phẩm */}
      <Image 
        source={require('./vs_blue.png')}
        style={styles.productImage}
      />

      {/* Tiêu đề sản phẩm */}
      <Text style={styles.productTitle}>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>

      {/* Đánh giá sản phẩm */}
      <Rating 
        imageSize={20}
        readonly
        startingValue={5}
        style={styles.rating}
      />
      <Text>(Xem 828 đánh giá)</Text>

      {/* Phần giá */}
      <View style={styles.priceContainer}>
        <Text style={styles.discountedPrice}>1.790.000 đ</Text>
        <Text style={styles.originalPrice}>1.790.000 đ</Text>
      </View>

      {/* Văn bản ưu đãi đặc biệt */}
      <Text style={styles.specialOffer}>Ở đâu rẻ hơn hoàn tiền</Text>

      {/* Tùy chọn màu sắc */}
      <TouchableOpacity 
        style={styles.optionButton}
        onPress={() => navigation.navigate('ColorSelection')}
      >
        <Text style={styles.optionButtonText}>4 MÀU - CHỌN MÀU</Text>
      </TouchableOpacity>

      {/* Nút mua hàng */}
      <TouchableOpacity style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// (styles không thay đổi)

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  productImage: {
    width: 300,
    height: 400,
    resizeMode: 'cover',
    marginBottom: 16,
  },
  productTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  rating: {
    marginVertical: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  discountedPrice: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'red',
    marginRight: 8,
  },
  originalPrice: {
    fontSize: 18,
    textDecorationLine: 'line-through',
    color: '#777',
  },
  specialOffer: {
    color: 'red',
    fontWeight: 'bold',
    marginVertical: 8,
  },
  optionButton: {
    backgroundColor: '#f0f0f0',
    padding: 12,
    borderRadius: 4,
    width: '100%',
    marginBottom: 16,
    alignItems: 'center',
  },
  optionButtonText: { 
    fontSize: 16,
    fontWeight: 'bold',
  },
  buyButton: {
    backgroundColor: 'red',
    padding: 16,
    borderRadius: 4,
    width: '100%',
    alignItems: 'center',
  },
  buyButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
export default ProductScreen;
