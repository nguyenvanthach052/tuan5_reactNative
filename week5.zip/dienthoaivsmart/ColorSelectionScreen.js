import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

const ColorSelectionScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <View style={styles.productContainer}>
        <Image
          source={require('./vs_blue.png')} // Correct usage
          style={styles.imagee}
        />
        <Text style={styles.productName}>Điện Thoại Vsmart Joy 3</Text>
        <Text style={styles.productInfo}>Hàng chính hãng</Text>
      </View>
      
      <Text style={styles.colorSelectionText}>Chọn một màu bên dưới:</Text>
      <View style={styles.colorOptions}>
        <TouchableOpacity style={[styles.colorBox, { backgroundColor: '#A0D9E1' }]} />
        <TouchableOpacity style={[styles.colorBox, { backgroundColor: 'red' }]} />
        <TouchableOpacity style={[styles.colorBox, { backgroundColor: '#000000' }]} />
        <TouchableOpacity style={[styles.colorBox, { backgroundColor: '#003DA5' }]} />
      </View>
      
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
 
  imagee: {
    height: 220,
    width: 200,
  },
  productContainer: {
    alignItems: 'center',
    marginBottom: 20,
  flexDirection:'row'
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productInfo: {
    fontSize: 16,
    color: 'gray',
  },
  colorSelectionText: {
    fontSize: 18,
    marginVertical: 10,
  },
  colorOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
  },
  colorBox: {
    width: 50,
    height: 50,
    borderRadius: 5,
    margin: 5,
  },
  button: {
    marginTop: 20,
    padding: 12,
    backgroundColor: 'blue',
    borderRadius: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
});

export default ColorSelectionScreen;